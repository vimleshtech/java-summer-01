package example;

public class Hello 
{

	int x;
	static int y;
	
	public static void main(String[] a){
		
		Hello o1 =new Hello();
		Hello o2 =new Hello();
		o1.x =10;
		o2.x =20;
		
		o1.y =10;
		o2.y =20;
		
		System.out.println(o1.x);
		System.out.println(o2.x);
		
		System.out.println(o1.y);
		System.out.println(o2.y);
		
		
		Hello.y=11;
		y =44;
		
		//Hello.x =44;
		//x =44;
		
				
		
	
		
				
		
	}

}
