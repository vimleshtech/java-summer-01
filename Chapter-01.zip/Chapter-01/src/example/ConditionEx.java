package example;

import java.util.Scanner;

public class ConditionEx {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		int amt;
		double tax;
		
		System.out.println("enter amt");
		amt  = s.nextInt();
		
		if(amt>1000)
		{
			tax = amt*.18;
			
		}
		else {
			tax = amt*.12; // amt*12/100
		}
		
		
		
		System.out.println(tax);

	}

}
