package example;

import java.util.Scanner;  //package 

public class InputExample {

	public static void main(String[] v)
	{		
		System.out.println("hi, this is my first code");
		
		Scanner s = new Scanner(System.in);
		int a,b,c;
		String name;
		
		
		System.out.println("enter number ");
		a = s.nextInt();
		
		System.out.println("enter number ");
		b = s.nextInt();
		
		System.out.println("enter name ");
		name= s.next();  //string 
		
		
		//expression 
		c =a*b;
		System.out.println("Output is "+c);
		
		
		System.out.println("name is : "+name);
		System.out.println("name is : "+name.toUpperCase());
		System.out.println("name is : "+name.toLowerCase());
		System.out.println("name is : "+name.length());
		System.out.println("name is : "+name.replace("a", "xy"));
		
		
		
		
		
		
	}
}
