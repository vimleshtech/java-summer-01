package filehandling;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileOperation {

	public static void main(String[] args) throws IOException {

		writeToFile();
		//appendToFile();
		readFromFile();
	}
	
	public static void writeToFile() throws IOException {
		
		//default mode is : false
		//new file will be created if file is not exist 
		FileWriter fw = new FileWriter("C:\\Users\\vkumar15\\Desktop\\test-file.txt");
		BufferedWriter bw = new BufferedWriter(fw);
		
		//bw.write("hi , this is my first file handling code..");
		//bw.newLine();
		//bw.write("end of code");
		
		Scanner sc = new Scanner(System.in);
		for(int i=0; i<5; i++)
		{
			System.out.println("enter string");
			String msg = sc.nextLine();
			 bw.write(msg);
			 bw.newLine();
		}
		
		bw.close();
		fw.close();
		System.out.println("data is saved");
		
		
	}
	public static void appendToFile() throws IOException {
	
		
		//new file will be created if file is not exist 
		FileWriter fw = new FileWriter("C:\\Users\\vkumar15\\Desktop\\test-file.txt",true);
		BufferedWriter bw = new BufferedWriter(fw);
		
		//bw.write("hi , this is my first file handling code..");
		//bw.newLine();
		//bw.write("end of code");
		
		Scanner sc = new Scanner(System.in);
		for(int i=0; i<5; i++)
		{
			System.out.println("enter string");
			String msg = sc.nextLine();
			 bw.write(msg);
			 bw.newLine();
		}
		
		bw.close();
		fw.close();
		System.out.println("data is saved");
				
		
	}
	public static void readFromFile() throws IOException {
		
		FileReader fr = new FileReader("C:\\Users\\vkumar15\\Desktop\\test-file.txt");
		BufferedReader br = new BufferedReader(fr);
		
		String line =br.readLine();
		
		//row count
		int rc=0;
		//word count
		int wc =0;
		while( line != null)
		{
			rc++;
			String words[] = line.split(" "); //this is java ={"this","is","java"}3
			//test code ={"test","code"}2
			wc+=words.length;
			
			System.out.println(line);
			line = br.readLine();
			
		}
		System.out.println("row count "+rc);
		System.out.println("word count "+wc);
		
		
		
		br.close();
		fr.close();
	}

}
