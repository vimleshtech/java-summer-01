package filehandling;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnection {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		writeData();
		readData();


	
	}
	
	public static void writeData() throws SQLException, ClassNotFoundException {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con  = DriverManager.getConnection("jdbc:mysql://localhost/javadb", "root", "root");
		PreparedStatement st = con.prepareStatement("insert into users(uid,name,emailid) values(?,?,?)");
		
		int eid=11;
		String name="Jatin";
		String email ="abc@gmail.com";
		
		st.setInt(1, eid);
		st.setString(2, name);
		st.setString(3, email);
		
		st.executeUpdate(); //insert,delete, update
		System.out.println("data is saved");
		con.close();

		
	}
	public static void readData() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con  = DriverManager.getConnection("jdbc:mysql://localhost/javadb", "root", "root");
		PreparedStatement st = con.prepareStatement("select * from  users");
		ResultSet rs = st.executeQuery(); //select
		
		while(rs.next()) {
			System.out.println(rs.getString(1)+"\t"+rs.getString(2));
		}
		
		con.close();
	}

}
