package threadExample;

import java.lang.Thread;
public class ThreadSample {

	public static void main(String[] args) throws InterruptedException {
		//Thread[main,5,main]
		Thread t = Thread.currentThread();		
		System.out.println(t);
		t.setName("Main-Thread");
		System.out.println(t);
	
		NewThread nt = new NewThread("new thread");
		
		for(int i=0;i<5;i++) {
			
			System.out.println(i);
			Thread.sleep(1000); //5 secs 
		}

	}

}

class NewThread implements Runnable{
	

	Thread nt =null;
	
	NewThread(String name){
		
		nt = new Thread(this,name);
		nt.start();
	}

	@Override
	public void run() {
	
		for(int i=10;i<15;i++) {
			
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} //1 sec 
		}
		

		
		
	}

}
