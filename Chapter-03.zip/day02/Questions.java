package day02;

public class Questions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		boolean a,b;
		a=true;
		b = false;
		
		System.out.println(!a);  //false
		System.out.println(!b);  //true 
		
		
		int i,j;
		i =21;
		j =30;
		
		System.out.println(~i);  
		System.out.println(~j);
		
		
		
	}

}
