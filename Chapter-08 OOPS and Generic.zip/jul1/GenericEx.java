package jul1;

import java.util.ArrayList;

class emp{
	int id;
	String name;
	int sal;
	emp(int id, String name, int sal){
		
		this.id =id;
		this.name =name;
		this.sal = sal;
	}
}
public class GenericEx {

	public static void main(String[] args) {
		
		
		ArrayList<emp>	 o =new ArrayList();
		//emp e =new  emp(1,"raman",4444);
		
		o.add(new  emp(1,"raman",4444));
		o.add(new  emp(2,"raman",43444));
		o.add(new  emp(10,"raman",44444));
		o.add(new  emp(100,"raman",45444));
		o.add(new  emp(13,"jatni",44544));
		
		
		for(int i=0;i<o.size();i++) {
			System.out.println(o.get(i).id);
			System.out.println(o.get(i).name);
			System.out.println(o.get(i).sal);
			
			
		}
		
		
		
		
	}

}
