package jul1;

public abstract  class AbsClass {
	
	abstract void add();
	abstract void add(int a , int b);
	void test() {
		
		System.out.println("test function");
	}
	

}
