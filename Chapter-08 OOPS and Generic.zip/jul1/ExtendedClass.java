package jul1;

public class ExtendedClass  extends AbsClass{

	@Override  //@Override : annotation 
	void add() {
		// TODO Auto-generated method stub
		System.out.println("add");
		
	}

	@Override
	void add(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a+b);
	}

}
