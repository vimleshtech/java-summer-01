package jul1;

public class Caller {

	public static void main(String[] args) {


		Parent p = new Parent();
		p.fun();//parent class function
		p.add(11, 33.4);
		
		
		//child

		Child c = new Child();
		c.fun();
		c.add(11, 33.4);
		c.add(11, 22);
		
		
		//overriding 
		Parent pp = new Child();
		pp.fun();
		pp.add(11,3);
		pp.add(11, 33.44);
		pp.add(11.44, 33.44);
		
		//or
		p=c;
		p.fun();//child class function
		
		
		//
		ExtendedClass ec =new ExtendedClass();
		ec.test();
		ec.add();
		ec.add(11,22);
		
		
		//
		TestImps t = new TestImps();
		t.add();
		t.div();
		t.fact();
		
	}

}
