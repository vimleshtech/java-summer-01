package jul1;

public interface Ib {

	void tax(int a);
	void gst(int a);
	int st(int a, float b);
	
	
}
