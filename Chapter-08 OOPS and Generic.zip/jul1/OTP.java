package jul1;

import java.util.Scanner;

public class OTP {

	public static void main(String[] args) {

		
		String name;
		String pan;
		int id;
		String mno;
		
		Scanner s=new Scanner(System.in);
		System.out.println("enter name ");
		name = s.nextLine();
		
		System.out.println("enter pan ");
		pan= s.nextLine();
		
		System.out.println("enter mno ");
		mno = s.nextLine();
		
		int n = pan.charAt(pan.length()-1); //ascii
		
		String pwd =
				name.substring(1, 2)+"00"+n+mno.substring(mno.length()-4, mno.length())+"001" ;
		
		System.out.println(pwd);
		
		
		

	}

}
