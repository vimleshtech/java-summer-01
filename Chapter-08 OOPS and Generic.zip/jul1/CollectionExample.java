package jul1;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;

public class CollectionExample {

	public static void main(String[] args) {

		ArrayList al = new ArrayList();
		al.add(11);
		al.add(11.444);
		al.add(true);
		al.add("test");		
		al.add(110);
		
		al.remove(1);
		al.add(1, 44);
		
		
		System.out.println(al.size());
		System.out.println(al.get(1));
		
		for(int i=0;i<al.size();i++) {
			System.out.println(al.get(i));
		}

		
		//
		ArrayList<String> s = new ArrayList<>();
		//ArrayList<String> s = new ArrayList<String>();
		//ArrayList<String> s = new ArrayList();
		
		s.add("shshgs");
		s.add("shshgs");
		s.add("shshgs");
		s.add("shshgs");
		
		System.out.println(s.size());
		
		//Dict : HashMap
		HashMap map =new HashMap();
		map.put("a", "alpha");
		map.put("t", "tata");
		map.put(10, 112344);
		map.put(2, "alphaf fuhfhgff");
		
		System.out.println(map.get("t"));
		
		
		
		
	}

}
