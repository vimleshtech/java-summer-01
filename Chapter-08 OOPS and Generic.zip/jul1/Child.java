package jul1;

public class Child  extends Parent{
	//overriding
	void fun() {
		
		System.out.println("test code - in child");
	}

	//overloading
	void add(int a, int b){
		
		System.out.println("sum of two numbers :"+(a+b));
		
	}	
	
	
}
