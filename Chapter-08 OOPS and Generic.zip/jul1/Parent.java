package jul1;

public class Parent {

	void fun() {
		
		System.out.println("test code - in parent");
	}

	void add(double a, double b){
		System.out.println(a+b);
	}	
	
}
