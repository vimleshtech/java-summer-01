package jul1;

public interface Ia {

	
	void add() ;
	void mul() ;
	void div() ;
	void mod() ;
	void fact() ;
	
	
	
	
}
