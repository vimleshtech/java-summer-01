package jul1;

public class TestImps  implements Ia,Ib{

	@Override
	public void tax(int a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void gst(int a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int st(int a, float b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void add() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mul() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void div() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mod() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fact() {
		// TODO Auto-generated method stub
		
	}
	

}
