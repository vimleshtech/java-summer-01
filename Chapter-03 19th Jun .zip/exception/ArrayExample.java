package example.exception;

public class ArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String s[]= {"raman","jatin","divya"};
		
		for(String d:s) {
			System.out.println(d);
		}
		
		//read using index
		System.out.println(s[1]); //print 2nd item 

		
		//
		int n[][] = {{11,22,334},{44,55,66}};
		
		for(int d[] : n) {
			for(int m: d)
				System.out.print(m+"\t");
			
			System.out.println();
		}
		
		
	}

}
