package example.exception;

public class B76_4 {

	public static void main(String[] args) {
	
		
		int inc =0,out=1;
		for(int i=1;i<10;i++)
		{
			System.out.print(out+",");
			
			out +=4+inc;
			inc+=2;
			
		}
		

	}

}
