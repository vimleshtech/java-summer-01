package example.exception;

import java.util.Scanner;

public class ExceptionTest {

	public static void main(String[] args) {
		
		int n[] = {11,222,333};
		
		
		try {
		
				for(int i=0; i<7; i++)
				{
					System.out.println(n[i]);
				}
				
		}
		catch(ArithmeticException e)
		{

		}
		catch (ArrayIndexOutOfBoundsException e) {
			
		}
		catch (Exception e) 
		{
			System.out.println("there is technical issues");
		}		
		finally {
			System.out.println("END OF CODE BLOCK--");
		}
		
		
		
		//div
		int num,d,o;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter data : ");
		num =sc.nextInt();
		
		System.out.println("enter data : ");
		d =sc.nextInt();
		
		try {
			
			if(d<0)
			{
				Exception out = new Exception("Divisor cannot be less than 0");
				throw out;  //jump to catch block with Exception type //just like go to statement
			}
			o =num/d;
			System.out.println("div out :" +o);
			
		}
		catch (Exception e) {
			
			System.out.println(e.toString());
		}
		
		
		
		

	}

}
