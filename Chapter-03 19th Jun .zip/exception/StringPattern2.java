package example.exception;

public class StringPattern2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s ="ABCDCBA";
		
		for(int i=0;i<s.length();i++)
		{	
			
			if(i<(s.length()/2)+1)
			{
				for(int si=i; si<s.length();si++) {
					System.out.print("_");
				}
				System.out.print(s.substring(0, i+1));
				
				for(int si=0; si<i;si++) {
					System.out.print(s.charAt(si));
				
				}
				
			}
			
			else {
				System.out.print("decrement");	
			}
			System.out.println();
			
			
		}
		
	}	

}
