package example.exception;

public class BreakExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=1;i<10;i++)
		{
			if(i%3==0)
				break;

			System.out.println(i);
		}

		
		///
		int n[] = {111,2222,5,55,343434,5555,3,50};
		for(int d: n) {
			
			if(d%5==0)
				break; //stop the loop 
			System.out.println(d);
			
		}
		
		//continue :print all numbers which will not be divided by 5
		
		for(int d: n) {
			
			if(d%5==0)
				continue; //skip the below code 
			
			System.out.println(d);
			//
			//
		}
		
		
	}

}
