package example.exception;

public class StrignPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String d="ABCDEFG";
		int sc=1;
		for(int i=0;i<d.length();i++)
		{	
			System.out.print(d.substring(0,d.length()-i));
	
			if(i>0) {
				for(int s=0;s<sc;s++) {
					System.out.print("_");
				}
				sc +=2;
				for(int ri=d.length()-1-i;ri>=0;ri--)
				{
					System.out.print(d.charAt(ri));				
				}
			}
			else
				for(int ri=d.length()-2-i;ri>=0;ri--)
				{
					System.out.print(d.charAt(ri));				
				}
			
			System.out.println();
		}

		
	}

}
