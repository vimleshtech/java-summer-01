package example.exception;

import java.util.Scanner;


public class DynamicArray {

	public static void main(String[] args) {

		Scanner s =new Scanner(System.in);
		int n[] = new int[5];
		
		for(int i=0;i<5;i++)
		{
			System.out.println("enter data ");
			n[i] = s.nextInt();
					
		}

		//print
		for(int d: n)
			System.out.println(d);
	}

}
