package example.oops;

import java.util.Scanner;

//class
public class Student {

		//data memebr : global variables
	public	int rno;
	private	String name;
	private	int hs,es,cs,total;
	private	float avg;
	private	String country="";
		
		
		public Student(){
			System.out.println("object is initialized");
			rno =100;
			name ="NA";
			
		}
		
		public Student(String country){
			if(country.equals("india")) {
				rno =1;
				name ="Guest User";
			}
			else {
				rno =1000;
				name ="New User";
			}
			
		}
		public Student(Student o){
			
			rno = o.rno;
			name = o.name;
			country = o.country;
			
		}
		//methods 
		public void input() {
			Scanner sc = new Scanner(System.in);
			System.out.println("enter rno");
			rno =sc.nextInt();
			
			System.out.println("enter name");
			name = sc.next();
			
			System.out.println("enter value for h");
			hs = sc.nextInt();
			
			System.out.println("enter value for e");
			es = sc.nextInt();
			
			System.out.println("enter value for c");
			cs =sc.nextInt();
			
		
			if (country.equals(""))
			{
				System.out.println("enter country");
				country =sc.next();
				
			}
		
			
		}
		
		public void cal() {
			
			total = hs+es+cs;
			avg = total/3;
			
		}
		public void show() {
			
			System.out.println("ROLL NO "+rno);
			System.out.println("Name "+name);
			System.out.println("Total marks "+total);
			System.out.println("Avg "+avg);
			System.out.println("Country "+country);
		}
		
}
