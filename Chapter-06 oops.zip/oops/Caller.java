package example.oops;

public class Caller {

	public static void main(String[] args) {

		Student s = new Student();
		//s.show();
		s.input();
		s.rno =11;
		//Student s2 = new Student("india");
		//s2.show();
		//Student s3 = new Student("us");
		//s3.show();
		
		
		Student o4 = new Student(s);
		o4.input();
		
		o4.cal();
		o4.show();
		
		s.cal();
		s.show();
		

	}

}
