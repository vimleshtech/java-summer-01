package banking;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class Startup {

	public static void main(String[] args) throws SQLException {
	
		Scanner s=new Scanner(System.in);
		BankTransaction bobj = new BankTransaction();

		
		while(true) {
			
			System.out.println("press 1 for new account 2 for login 3 for exit");
			int ch = s.nextInt();
			
			if(ch==1)
			{
					System.out.println("in option 1");
					bobj.newAccount();
					System.out.println("new account is created!");
					
			}
			else if(ch==2)
			{	
				System.out.println("in option 2");
				boolean isLogin = bobj.login();
				
				if(isLogin) {
					System.out.println("Welcome  to ABC Bank !!!!");
			
					while(true) {
					System.out.println("press 1 for deposit 2 for withdrawn 3 for statement  0 for exit");
					int inCh = s.nextInt();
					
					if(inCh==1) {
						bobj.add_amount();
							
					}
					else if(inCh==2) {
						
						bobj.withdraw_amt();
					}
					else if(inCh==3) {
						bobj.summary();
					}
					else if(inCh==0) {
						System.exit(0);
						
						//break;
					}
					else {
						System.out.println("invalid choice ...");
					}
					
					}
				}
				else {
					System.out.println("Given details is not correct, plz try again");
				}
				
				
			}
			else if(ch==3)
			{
					System.out.println("logout!!!");
					break;
			}
			else {
				
					System.out.println("Invalid choice , plz try again !!!");
			}
			
			
			
			
		}
		

	}

}
