package banking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class BankTransaction {

	private Connection con = null;
	private PreparedStatement ps=null;
	private ResultSet rs = null;
	private Scanner sc = null;
	
	private String host="localhost";
	private String user="root";
	private String pwd="root";
	private String url="jdbc:mysql://"+host+"/banking";
	private int acno;
	
	BankTransaction(){
	
		try {			
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pwd);
			
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
	public void newAccount() throws SQLException {
	

		sc = new Scanner(System.in);
		
		System.out.println("enter account type (1 for saving and 2 for current) :");
		int actype = sc.nextInt();
				
		System.out.println("enter fname:");
		String fname = sc.next();
		
		System.out.println("enter lname:");
		String lname = sc.next();
		
		System.out.println("enter email:");
		String email = sc.next();
		
		System.out.println("enter phone:");
		String phone = sc.next();
		
		System.out.println("enter gender:");
		String gender = sc.next();
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

		String date = simpleDateFormat.format(new Date());
		
		
		ps = con.prepareStatement("insert into account(fname,lname,email,phone,gender,atid,status,create_date) values(?,?,?,?,?,?,?,?)");
		ps.setString(1, fname);
		ps.setString(2, lname);
		ps.setString(3, email);
		ps.setString(4, phone);
		ps.setString(5, gender);
		ps.setInt(6, actype);
		ps.setString(7, "A");
		ps.setString(8, date);
		
		
		ps.executeUpdate(); 
		
	}
	public boolean login() throws SQLException {
	
		sc = new Scanner(System.in);
		
		System.out.println("enter account no:");
		acno = sc.nextInt();
				
		System.out.println("enter email:");
		String email= sc.next();
		
		ps = con.prepareStatement("select * from account where email=? and acid =? ");
		
		ps.setString(1, email);
		ps.setInt(2, acno);
		
		rs = ps.executeQuery();
		
		boolean flag = false;
		while(rs.next()) {
			flag = true;
		}
		
		return flag;
	}
	public void summary() throws SQLException {
		
		ps = con.prepareStatement("select * from transaction where acid=?");
		ps.setInt(1, acno);
		
		rs = ps.executeQuery();
		
		
		while(rs.next()) {
			System.out.println(rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5));
			
				
		}
		
		
		
		
	}
	
	public void add_amount() throws SQLException {
		
		//acno
		sc = new Scanner(System.in);
		
		System.out.println("enter amount (for deposit):");
		int amt = sc.nextInt();

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

		String date = simpleDateFormat.format(new Date());

		
		ps = con.prepareStatement("insert into transaction(acid,amt,tran_date,tran_type) values(?,?,?,?)");
		ps.setInt(1, acno);
		ps.setInt(2, amt);
		ps.setString(3, date);
		ps.setString(4, "D");
		
		ps.executeUpdate();
		
	}
	public void withdraw_amt() throws SQLException {

		//acno
				sc = new Scanner(System.in);
				
				System.out.println("enter amount (for withdrawn):");
				int amt = sc.nextInt();

				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

				String date = simpleDateFormat.format(new Date());

				
				ps = con.prepareStatement("insert into transaction(acid,amt,tran_date,tran_type) values(?,?,?,?)");
				ps.setInt(1, acno);
				ps.setInt(2, amt);
				ps.setString(3, date);
				ps.setString(4, "C");
				
				ps.executeUpdate();
								
	}
	
	
}

