package day01;

public class DataType {

	public static void main(String[] args) {

		
		byte b=11;
		short s =10000;
		int i =433333333;
		long l =544444444444444444l;
		
		
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		
		//
		float f =54334.444f;
		double d =543333333.4444444;
		System.out.println(f);
		System.out.println(d);
		
		
		//
		char c='1';
		System.out.println(c);
		
		//
		boolean bb = true;
		System.out.println(bb);
		

	}

}
