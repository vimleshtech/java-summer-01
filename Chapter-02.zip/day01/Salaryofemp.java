
public class Salaryofemp 
{

	public static void main(String[] args) 
	{
		
		
			int sal;
			sal =5555;
			
			double hra,da;
			
		
			if(sal >5000 && sal<10000) 
			{
				
				hra = sal*.10;
				da= sal*.05;
				System.out.println(hra);
				System.out.println(da);
			}
			else if(sal >10000 && sal<15000) 
			{

				hra = sal*.15;
				da= sal*.08;
				
				System.out.println(hra);
				System.out.println(da);
			}
			
	}
			
}

