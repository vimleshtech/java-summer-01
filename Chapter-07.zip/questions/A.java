package oos.questions;

public class A {

	void  add(int a, int b)
	{
		System.out.println(a+b);
		
	}
	void  mul(int a, int b)
	{
		System.out.println(a*b);
		
	}
	
	void  div(int a, int b)
	{
		System.out.println(a/b);
		
	}
	
}
