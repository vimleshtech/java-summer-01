package oos.questions;

public class Inherit_Caller {

	public static void main(String[] args) {

		//A o = new A();
		B o =new  B();
		o.add(11, 3);
		o.mul(11, 2);
		o.div(3434, 3);
		
		o.tax(3333);
		
		
		//multi level 
		C c = new C();
		c.add(11, 3);
		c.div(1, 2);
		c.tax(44444);
		c.sub(44, 34);
		

		///
		SavingAccount sa = new SavingAccount();
		sa.newAccount(100, "Raman Sinha", 11122,"BGRPK0155J","VID");
	
		CurrentAccount ca = new CurrentAccount();
		ca.newAccount(200, "AB pvt. ltd.", 55676444,"APRPK0155J","jk3245222");
		
		sa.disp();
		ca.disp();
	
		
	}

}
