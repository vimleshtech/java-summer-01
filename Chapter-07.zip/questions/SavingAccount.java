package oos.questions;

public class SavingAccount extends BankAccount {

	String pan;
	String id;
	

	void newAccount(int accno, String acname, int amt,String pan, String id) {
		
		super.newAccount(accno, acname, amt);
		this.pan = pan;
		this.id = id;
		
		
	}
	
	public void disp() {
		
		super.disp();
		System.out.println(this.pan);
		System.out.println(this.id);
		
	}
	
}
