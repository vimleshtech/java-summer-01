package oos.questions;

import java.util.Scanner;

public class J2 {

	int rno;
	String name;
	
	void input() {
		
		Scanner sc1 =new Scanner(System.in);
		Scanner sc2 =new Scanner(System.in);
		
		System.out.println("ente rno ");
		rno = sc1.nextInt();
		
		System.out.println("ente  name ");
		name = sc2.nextLine();
		
		
	}
	int rno() {
	
			return rno;
	}
	
	void show() {
		System.out.println(rno);
		System.out.println(name);
	}
	
	
}

