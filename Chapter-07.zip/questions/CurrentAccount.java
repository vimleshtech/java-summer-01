package oos.questions;

public class CurrentAccount extends BankAccount{
	
	String gstn;
	String regproof;
	
	void newAccount(int accno, String acname, int amt,String gstn, String id) {
		
		super.newAccount(accno, acname, amt);
		this.gstn = gstn;
		this.regproof = id;
		
		
	}
	
	public void disp() {
		
		super.disp();
		System.out.println(this.regproof);
		System.out.println(this.gstn);
		
	}
	

	
}
