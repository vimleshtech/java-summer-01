package oos.questions;

public class BankAccount {

	int accno;
	String acname;
	int amt;
	
	void newAccount(int accno, String acname, int amt) {
		this.accno = accno;
		this.acname = acname;
		this.amt = amt;
		
		
	}
	
	public void disp() {
		
		System.out.println(this.accno);
		System.out.println(this.acname);
		System.out.println(amt);

	}
	
	
}
