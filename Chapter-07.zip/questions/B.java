package oos.questions;

public class B extends A {

	
	void tax(int amt) {
	
		if(amt>10000)
		{
			System.out.println(amt*.20);
		}
		else {
			System.out.println(amt*.10);
		}
	}
}
