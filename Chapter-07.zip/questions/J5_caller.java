package oos.questions;

import java.util.Scanner;

public class J5_caller {

	public static void main(String[] args) {
		
		J2 o[] = new J2[3];
		for(int i=0;i<3;i++)
		{
			o[i] = new J2();
			o[i].input();
		
		}
		//sorting 
		for(int i=0;i<3;i++)
		{
			for(int j=i+1; j<3;j++) {
				
				if(o[i].rno() > o[j].rno()) {
					
					J2 temp = o[i];
					o[i] = o[j];
					o[j] = temp;
				}
				
			}
		}
		//print
		for(J2 j : o) {
		//for(int i=0; i<3;i++) {
			//o[i].show();
			j.show();
		}
		//find  or search
		Scanner s =new Scanner(System.in);
		System.out.println("enter rno ");
		int rno  = s.nextInt();
		for(J2 j : o) {
				if(j.rno() == rno)
						j.show();
			}
		

	}

}
