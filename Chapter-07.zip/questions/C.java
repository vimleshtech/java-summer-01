package oos.questions;

public class C extends B {

	void sub(int a, int b) {
		System.out.println(a-b);
	}
}
