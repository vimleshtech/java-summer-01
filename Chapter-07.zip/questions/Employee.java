package oos.questions;

public class Employee {

	static int eid;
	static  String name;
	static  int salary;
	static int netsalary;
	final static  int cess = 5;

	int a;
	static int b;
	
	
	static void set_data(int eid,String name, int sal) {
		
		
		eid = eid;
		name = name;
		salary = sal;
		netsalary = salary-cess;
		
		
	}
	static  void show() {
		System.out.println(eid);
		System.out.println(name);
		System.out.println(salary);
	}
}
