package oos.questions;

import java.util.Scanner;

import questions.Emp;

public class Employee_Caller {

	public static void main(String[] args) {
	
		Employee e1 = new Employee();
		Employee e2 = new Employee();
		e1.a =11;
		e1.b =22;
		
		e2.a =110;
		e2.b =220;
		
		System.out.println(e1.a);//11    11
		System.out.println(e1.b);//22    220
		System.out.println(e2.a);//110   110
		System.out.println(e2.b);//220   220
		
		//Employee.a =11;
		Employee.b =11;
		//System.out.println();
		//Scanner.nextInt();
		
		Employee.set_data(11, "Jatin", 3444);
		Employee.show();
		
		

	}

}
