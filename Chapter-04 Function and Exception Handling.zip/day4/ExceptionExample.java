package day4;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class ExceptionExample {

	public static void main(String[] args) throws FileNotFoundException, InterruptedException {
	

		//FileReader fr = new FileReader("c:\\abc\\a.txt");
		
		
		//Thread.sleep(400);
		
		
		int n,d,o;
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("enter num :");
		n = s.nextInt();
		
		System.out.println("enter num :");
		d = s.nextInt();
		
		//div
		try {
			
			if(d<0)
			{
				Exception ee =new Exception("divisor cannot less than 0");
				throw ee;//jump to Exception block
			}
			o = n/d;
			System.out.println("div = "+o);
			 
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		catch (ArithmeticException e) {
			System.out.println("arithmetic error");
		}
		catch (Exception er) { //Exception: is class , er is object
			
			System.out.println("there is issue in data "+er);
		}
		finally {
			//logout
			System.out.println("end of div block");
		}
				
		//add
		o = n+d;
		System.out.println("sum is   "+o);
		
		
		
		

	}

}
