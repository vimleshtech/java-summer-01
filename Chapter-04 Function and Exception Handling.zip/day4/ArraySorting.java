package day4;

import java.util.Scanner;

public class ArraySorting {

	
	public static void main(String[] args) {
		
	
		Scanner sc = new Scanner(System.in);
		int n[] = new int[10];
		
		int d= 0;
		

		for(int i=0;i<10;i++)
		{
			System.out.println("enter numbers ");
			n[i] = sc.nextInt();
			
		}
		
		for(int r=0; r<10;r++)
		{
			for(int c=0; c<10;c++)
			{
					if(n[r]>n[c])
					{
						int t = n[r];
						n[r] = n[c];
						n[c] =t;
					}
			}
			
			
		}
		

		for(int nd : n) {
			System.out.println(nd);
		}


		//a={111,22,333,445,11,22,4,5}
		//3
		//a={333,445,11,22,4,5,111,22}
		//newa {11,22,4,5,111,22}
		
		//n
		int newa[] = new int[10];
		System.out.println("enter index ");
		int r = sc.nextInt();
		//3
		int ind =0;
		for(int i=r;i<10;i++) { //3 to <10
			
			newa[ind] = n[i];
			ind++;
			
		}
		
		for(int i=0;i<r;i++) {			
			newa[ind] = n[i];
			ind++;
		}
		
		for(int x: newa)
			System.out.println(x);
		
	}

}

