package day4;

import java.util.Scanner;

public class FunctionExaple {

	public static void main(String[] args) {


		//call to function 
		test();
		//test();
		
		
		int a,b;
		a = getNum();
		b = getNum();
		
		System.out.println(a+b);
		
		a = getNum();
		b = getNum();
		System.out.println(a*b);
		
		//add
		add(a,b);
		
		add(1333,44);
		add(getNum(),getNum());
		
		
		//mult 
		int o = mul(11,33);
		System.out.println(o);
	
		o = mul(getNum(),getNum());
		System.out.println(o);

		
		//fact
		int f = fact(6);
		System.out.println(f);
	}
	

	//no argument no return 
	public static void test() {
		
		System.out.println("this is function -test code");
		System.out.println("this class file conains multiple functions 1. main 2. test 3. add ...");
	}
	
	//no argument with return
	public static int getNum() {
		
		
		Scanner s = new Scanner(System.in);
		int n;
		System.out.println("enter data  ");
		n = s.nextInt();
		
		return n;
		
		
	}
	
	//argument with no return 
	public static void add(int a, int b) {
		
		int c =a+b;
		System.out.println("sum of two numbers in function :"+c);
	}
	
	//argument with return 
	public static int mul(int x, int y) {
		return x*y;
	}
	
	//recussive
	public static int fact(int x) {
		
		if (x==1)
			return x;
		else
			return x*fact(x-1);
	}
}
