package dataacces;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DBAction {
	
	public String CreateData(String name, String email) {
		
		String msg ="";
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con  = 
					DriverManager.getConnection("jdbc:mysql://localhost/javadb", "root", "Karan@9953preet");

			PreparedStatement ps = 
					con.prepareStatement("insert into test(name,email) values(?,?)");
			
			ps.setString(1, name);
			ps.setString(2, email);
			
			ps.executeUpdate();
			msg ="data is saved";
			
		}
		catch (Exception e) {
			// TODO: handle exception
			msg = e.toString();
					
		}
		return msg;
	}

}
