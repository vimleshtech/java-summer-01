package example;

import java.util.Scanner;



public class Test1 
{

	public static void main(String[] arg) 
	{
	
		//This is my first code  in java 
		System.out.println("Hi, this is my fist code");
		
		/*
		System.out.println(1);
		System.out.println("2");
		System.out.println(3);
		*/
		
		System.out.print("hi");
		System.out.print("Nitin");
		
		
		System.out.println("\nhi");
		System.out.print("Nitin \tSinha");
		
		//
		
		Scanner sc = new Scanner(System.in);
		String name;
		System.out.println("enter name ");
		//name = sc.next(); 
		name = sc.nextLine();
		
		System.out.println("you have entered  :"+name);
		
		
		
	}
}
