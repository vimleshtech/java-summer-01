package example;

import java.util.Scanner;

public class StringExample {

	public static void main(String[] ar)
	{
		
		Scanner s = new Scanner(System.in);
		String str,news;
		
		System.out.println("etner string vaue ");
		str = s.nextLine();
		
		int l = str.length();
		System.out.println(l);
	
		news = str.toUpperCase();
		System.out.println(news);
	
		news = str.toLowerCase();
		System.out.println(news);
	
		news = str.replace("i", "are");//oldvalue, newvalue 
		System.out.println(news);
	
		
		
		int ps = str.indexOf("is");  //return -1 if not match
		System.out.println(ps);
		
		
		char c = str.charAt(6);
		System.out.println(c);
		
		//convert char to ascii
		int a = c;
		System.out.println(a);
		
		news = str.substring(5, 12); //from 5 to <12
		System.out.println(news);
		
		String n[] = str.split(" ");
		System.out.println("char count "+str.length());
		System.out.println("count of word "+n.length);
		
		System.out.println(n[0]); //return first name
		
		//
		String fn,ln;
		fn ="Raman";
		ln ="sharma";
		
		
		news = fn.concat(ln);
		System.out.println(news);
		
		//or
		news = fn+ ln;
		System.out.println(news);
		
	}
}
