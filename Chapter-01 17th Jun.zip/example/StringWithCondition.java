package example;

import java.util.Scanner;

public class StringWithCondition {

	public static void main(String[] a)
	{
		Scanner s = new Scanner(System.in);
		String str;
		
		System.out.println("enter string :");
		str = s.nextLine();
		
		if(str.contains("is"))
		{
			System.out.println("is is match");
		}
		else 
		{
				System.out.println("not match");
			
		}
		//
		if(str.startsWith("is"))
		{
			System.out.println("start with is");
		}
		else 
		{
				System.out.println("not match");
			
		}
		
		//
		if(str.endsWith("n"))
		{
			System.out.println("end with n");
		}
		else 
		{
				System.out.println("not match");
			
		}
		
		//
		if(str.equals("this is java"))
		{
			System.out.println("match");
		}
		else 
		{
				System.out.println("not match");
			
		}
		//
		if(str.equalsIgnoreCase("this is java"))
		{
			System.out.println("match");
		}
		else 
		{
				System.out.println("not match");
			
		}
	}
}
