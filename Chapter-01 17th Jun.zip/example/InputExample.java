package example;

import java.util.Scanner;

public class InputExample {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		int a,b,c;
		
		System.out.println("enter data : ");
		a = sc.nextInt();
		
		System.out.println("enter data : ");
		b = sc.nextInt();
		
		
		c = a*b;
		System.out.println("output is "+c);

	}

}
