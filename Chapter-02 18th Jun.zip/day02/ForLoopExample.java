package day02;

public class ForLoopExample {

	public static void main(String[] a)
	{
		
		for(int i=2; i<=20; i=i+2) {
			
			System.out.println(i);
		}
		
		//in rev
		for(int i=10;i>0;i--)
		{
			System.out.println(i);
		}
		
		//sum of all even and odd numbers
		int se=0,so=0;
		for(int i=1;i<=120;i++)
		{
			if(i%2 == 0)
			{
				se +=i;
			}
			else
			{
				so+=i;
			}
		}	
		System.out.println(se);
		System.out.println(so);
	}
	
	
}
