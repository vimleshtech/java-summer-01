package day02;

import java.util.Scanner;

import javax.sound.midi.Soundbank;

public class B40 {

	public static void main(String[] args) {

		int sn,en;
		Scanner s = new Scanner(System.in);
		
		System.out.println("enter first no ");
		sn = s.nextInt();
		
		System.out.println("enter 2nd no ");
		en = s.nextInt();
		
		
		int sum =0;
		for(int i=sn;i<=en;i++) {
			
			
			if(i%2 ==0 && i%3 ==0 && i%5 !=0) {
				
				sum+=i;
			}
		}
		
		System.out.println(sum);
		
		

	}

}
