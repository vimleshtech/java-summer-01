package day02;

public class B76_6 {

	public static void main(String[] args) {
		
		for(int i=1; i<6;i++) {
			
			for(int j=0;j<i;j++)
			{
				System.out.print(j);
			}
			System.out.println();
		}
		
		for(int i=1; i<6;i++) {
			
			for(int j=0;j<5;j++)
			{
				System.out.print("*");
				
			}
			System.out.println();
		}
		
		for(int i=1; i<6;i++) {
			
			for(int j=0;j<i;j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}

		for(int i=1; i<6;i++) {
			
			for(int j=i;j<6;j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}

		
		// 
		// i =1 j = 0 1  
		// i =2 j = 0 1  
		// i =3 j = 0 1
		// i =4 j = 0 1 
		// i =5 j = 0 1 
		
		for(int i=2; i<20;i=i+2) {
			
			System.out.print("(");
			for(int j=2;j<=i;j=j+2)
			{
				if(j<i)
					System.out.print(j+"+");
				else
					System.out.print(j);
			}
			System.out.print(")+");
		}
	
	
		
	}

}
