package day02;

public class WhileExample {

	public static void main(String[] args) {

		
		int x,y;
		x =0;
		y =0;
		System.out.println(x++);//0
		System.out.println(++y);//1
		
		
		System.out.println(x);//1 
		System.out.println(y);//1 
		
		//Example 1:
		int i=1;
		while(i<=10) {  
			//System.out.println(i); //print and new line 
			System.out.print(i);  //print and don't change line
			i++;
		}

		//print in reverse order
		i =10;
		while(i>0) {
			System.out.println(i);
			i--;
		}
		
		//wap to print of 4
		i =1;
		while(i<=10) {
			
			System.out.println(i*4);
			i++;
		}
		
			
		//wap to get sum of all even and odd numbers between 1 to 120
		int se = 0 ,so=0;
		i =1;
		while(i<=120) {
			
			if(i%2 ==0) //even
			{
				se = se+i;  //2+4+6....
			}
			else {
				so+=i;  //1+3+5+7....
			}
			
			i++;
		}
		
		System.out.println("sum of all even "+se);
		System.out.println("sum of all odd  "+so);
		
		
		
		
		
	}

}

