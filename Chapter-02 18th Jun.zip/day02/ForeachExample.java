package day02;

import javax.sound.midi.Soundbank;

public class ForeachExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n[] = {111,222,3334,555,666,111};
		for(int d: n) 
			System.out.println(d);
		
		//wap to get sum of all numbers
		int s =0;
		for(int d: n)
			s+=d;
		
		System.out.println("sum of all numbers  "+s);
		
		//for
		s=0;
		for(int i=0; i<5;i++)
			s+=n[i];
		
		System.out.println("sum of all numbers  "+s);
		
	}

}
