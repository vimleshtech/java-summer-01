package day02;

public class DoWhileExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n=1;
		do {
			
			System.out.println(n);
			n++;
		}while(n<0);
	
	}

}
